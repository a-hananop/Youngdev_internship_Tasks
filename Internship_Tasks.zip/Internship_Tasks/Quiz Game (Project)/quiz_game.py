import pyttsx3

def speak(text):
    engine = pyttsx3.init()
    engine.say(text)
    engine.runAndWait()

class Question:
    """
    Represents a multiple-choice question.
    """
    def __init__(self, prompt, options, correct_answer):
        self.prompt = prompt
        self.options = options
        self.correct_answer = correct_answer.upper()

    def display(self):
        """
        Display the question and options.
        """
        print(f"\n{self.prompt}")
        for option in self.options:
            print(option)

    def check_answer(self, user_answer):
        """
        Return True if the answer is correct.
        """
        return user_answer.upper() == self.correct_answer


class QuizGame:
    """
    The main quiz game class.
    Handles logic, scoring, and results.
    """
    def __init__(self, questions):
        self.questions = questions
        self.score = 0
        self.user_answers = []
        self.total_questions = len(questions)

    def start(self):
        """
        Start the quiz.
        """
        self.show_intro()

        for index, question in enumerate(self.questions, start=1):
            print(f"\n--- Question {index} ---")
            self.ask_question(question)

        self.show_results()

    def show_intro(self):
        """
        Show welcome screen.
        """
        print("=" * 50)
        print("Welcome to the Python Programming Quiz Game!")
        speak("Welcome to the Python Programming Quiz Game!")  # Voice
        print("=" * 50)
        print(f"You'll be asked {self.total_questions} questions.\nGood luck!")

    def ask_question(self, question):
        """
        Ask a question and get user's answer.
        """
        question.display()
        user_answer = self.get_user_answer()
        correct = question.check_answer(user_answer)

        if correct:
            print("\tCorrect!")
            speak("\tCorrect!")
            self.score += 1
        else:
            print(f"Wrong! Correct answer: {question.correct_answer}")
            speak(f"Wrong! Correct answer: {question.correct_answer}")

        self.user_answers.append((question, user_answer, correct))

    def get_user_answer(self):
        """
        Get and validate user input.
        """
        answer = input("Your answer (A, B, C, D): ").strip().upper()
        while answer not in ['A', 'B', 'C', 'D']:
            print("Invalid input.")
            answer = input("Please enter A, B, C, or D: ").strip().upper()
        return answer

    def show_results(self):
        """
        Display final score and summary (no review).
        """
        print("\n" + "=" * 30)
        print("Quiz Complete!")
        print("=" * 30)

        incorrect = self.total_questions - self.score

        print(f"Correct answers  : {self.score}")
        print(f"Incorrect answers: {incorrect}")
        print(f"Total questions  : {self.total_questions}")

        percentage = (self.score / self.total_questions) * 100
        print(f"\nYour score: {self.score}/{self.total_questions} ({percentage:.1f}%)")

        if percentage == 100:
            print("============================================")
            print("*** Perfect score! You're a Python pro! ***")
            speak("*** Perfect score! You're a Python pro! ***")  
            print("============================================")
        elif percentage >= 80:
            print("Great job! Keep it up.")
            speak("Great job! Keep it up.")
        elif percentage >= 50:
            print("Not bad. A little more practice and you'll get there.")
            speak("Not bad. A little more practice and you'll get there.")
        else:
            print("Keep learning. Python takes time!")
            speak("Keep learning. Python takes time!")


def load_questions_from_file(filename):
    """
    Load questions from a text file and return a list of Question objects.
    """
    questions = []
    try:
        with open(filename, 'r', encoding='utf-8') as file:
            content = file.read().strip()
            blocks = content.split('\n\n')

            for block in blocks:
                lines = block.strip().split('\n')
                if len(lines) == 6:
                    prompt = lines[0]
                    options = lines[1:5]
                    answer = lines[5]
                    questions.append(Question(prompt, options, answer))
                else:
                    print("Skipping malformed question block.")
    except FileNotFoundError:
        print(f"Error: File '{filename}' not found.")
    return questions


def main():
    """
    Entry point of the game.
    """
    filename = "questions.txt"
    questions = load_questions_from_file(filename)

    if not questions:
        print("No questions loaded. Exiting.")
        return

    quiz = QuizGame(questions)
    quiz.start()


if __name__ == "__main__":
    main()
